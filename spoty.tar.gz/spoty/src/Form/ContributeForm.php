<?php

/**
 * @file
 * @author Juan Ceballos
* Primarily Drupal hooks and global API functions.
*/

namespace Drupal\spoty\Form;
use Drupal\Core\Form\FormBase;
use Drupal\Core\Form\FormStateInterface;
use Drupal\Component\Utility\UrlHelper;
use Drupal\Core\Url;

/**
 * Contribute form.
 */
class ContributeForm extends FormBase {
  /**
   * {@inheritdoc}
   */

  public function getFormId() {
    return 'spoty_contribute_form';
  }

  /**
   * {@inheritdoc}
   */

  public function buildForm(array $form, FormStateInterface $form_state) {

     $form['endpoint'] = array(
      '#type' => 'textfield',
      '#title' => t('End Point'),
      '#required' => TRUE,
      '#default_value' =>  \Drupal::state()->get('endpoint'),
      '#description' => t('End Point: https://accounts.spotify.com/api/token'), 
    );
     $form['cliend_id'] = array(
      '#type' => 'textfield',
      '#title' => t('Client(%)id'),
      '#required' => TRUE,
      '#default_value' =>  \Drupal::state()->get('cliend_id'),
       '#description' => t('Client(%)id: ab2c563b8cd84ea7892c53aa593d1f33'), 
    );
     $form['cliend_secret'] = array(
      '#type' => 'textfield',
      '#title' => t('Client Secret'),
      '#required' => TRUE,
      '#default_value' =>  \Drupal::state()->get('cliend_secret'),
      '#description' => t('Client Secret: 9406023f1bf54f9ba7b989f9b8b85544'), 
    );

    $form['token'] = [
      '#type' => 'item',
      '#title' => t('Your Access Token Spoty is:'),
      '#markup' => getTokenSpoty(),
    ];

    $form['lanzamientos'] = [
      '#type' => 'item',
      '#title' => t('Access Lanzamientos'),
      '#markup' => \Drupal::l(t('Internal Link'), Url::fromUri('internal:/spoty/lanzamientos')),
    ];

    $form['submit'] = array(
      '#type' => 'submit',
      '#value' => t('Save'),
    );
    return $form;
  }

  /**
   * {@inheritdoc}
   */

  public function validateForm(array &$form, FormStateInterface $form_state) {
  }

  /**
   * {@submitForm}
   */

  public function submitForm(array &$form, FormStateInterface $form_state) {
    foreach ($form_state->getValues() as $key => $value) {
      \Drupal::state()->set($key,$value);
    }
  }
}

  /**
   * {@getTokenSpoty}
   */

  function getTokenSpoty(){
   
    $url =  \Drupal::state()->get('endpoint');
    $data = array('grant_type' => 'client_credentials', 'client_id' => \Drupal::state()->get('cliend_id'),'client_secret' => \Drupal::state()->get('cliend_secret'));

    $options = array(
        'http' => array(
            'header'  => "Content-type: application/x-www-form-urlencoded\r\n",
            'method'  => 'POST',
            'content' => http_build_query($data)
        )
    );

    $context  = stream_context_create($options);
    $result = file_get_contents($url, false, $context);
    $params = explode('","',file_get_contents($url, false, $context));
    $token = explode('":"',array_shift($params));
  
    return $token[true];
  }


?>